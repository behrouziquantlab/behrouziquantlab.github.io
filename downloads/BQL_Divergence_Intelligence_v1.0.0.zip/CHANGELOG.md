# Changelog — BQL Divergence Intelligence

## 1.0.0 — 2026-11-11
**Added:**
- First release.
- Regular and hidden divergence on M5 and M1, each with MACD 3,5,2 and 12,26,9.
- Signal lifecycle: FORMING, CONFIRMED and INVALIDATED.
- Chart labels with pivot and confirmation times.
- Pivot lines.
- Information panel with engines, history and health. Light and dark themes.
- Alerts: popup, sound and push, set separately for each stage and timeframe.

**Tested:**
- Engine regression is identical to the verified reference (EURAUD M5 and M1).
