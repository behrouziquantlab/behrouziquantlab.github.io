# BQL Divergence Intelligence — End-User Licence Agreement (v1.0)
1. BEHROUZI QUANT LAB grants you a non-exclusive, non-transferable licence to use the compiled indicator on the MetaTrader 5 account number(s) your licence key is issued for.
2. Demo accounts may run the indicator free of charge as a trial.
3. You may not decompile, resell, share or publish the software or your licence key.
4. The software is an analysis and alert tool. It does not execute trades and does not provide investment advice. Trading carries substantial risk; you alone are responsible for your trading decisions.
5. The software is provided "as is". To the extent permitted by law, BEHROUZI QUANT LAB is not liable for trading losses.
6. Licence transfers to another account are possible on request through support.
