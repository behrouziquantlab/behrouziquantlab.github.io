# BQL Divergence Intelligence — User Manual (v1.0.0)

*BEHROUZI QUANT LAB · powered by BQL QUANT ENGINE*

BQL Divergence Intelligence detects **regular** and **hidden** MACD divergences on **M5** and **M1**. Each timeframe runs two independent MACD engines: **3,5,2 (fast)** and **12,26,9 (standard)**. Every signal goes through a transparent lifecycle. Only closed candles are used.

> **The indicator analyses and alerts only. It never opens, closes or modifies trades.**
> Divergence is a market-structure observation, not a guarantee. In our own historical tests, divergence on its own showed **no statistical edge** (about 50% at a 1R target). Use it as one input of your own process.

## 1. Installation
1. In MetaTrader 5, open **File → Open Data Folder**.
2. Copy the files:
   - `BQL_Divergence_Intelligence.ex5` → `MQL5\Indicators\BQL\`
   - The `BQL\*.mqh` files → `MQL5\Include\BQL\` (source package only)
3. Restart MT5, or right-click **Navigator → Refresh**.
4. Drag **BQL_Divergence_Intelligence** onto an **M1** or **M5** chart.
5. If you want mobile push alerts, enable them in **Tools → Options → Notifications**.

**Requirements:**
- MetaTrader 5, build 4000 or newer, Windows.
- Any symbol.
- Enough history: by default the last 6,000 M5 and 9,000 M1 bars are processed.

## 2. What you see

### Chart labels
| Label | Meaning |
|---|---|
| `HD▲ M5·S` | **Confirmed** hidden bullish divergence, M5, standard MACD |
| `RD▼ M1·F` | **Confirmed** regular bearish divergence, M1, fast MACD |
| `HD?▲ M5·F` (faint colour, dotted line) | **Forming**: seen one bar after the swing; may still be invalidated |

- **Placement:** a label sits on the second price pivot.
- **Tooltip:** hover a label to see the pivot time, the confirmation time, and how many bars after the pivot it was confirmed.
- **Lines:** a line joins the two price pivots.

### Panel
- **Header:** symbol, LIVE/LOADING status, number of alerts.
- **Engines:** the last confirmed signal and the number of forming signals for each of the 4 engines (M5/M1 × fast/standard).
- **Signal history:** the 8 newest confirmed divergences across all engines.
- **Alerts & health:** the active alert types, the last alert, bars processed, processing time and chart objects.
- Click a section header to collapse or expand it.

## 3. Signal lifecycle
| State | When |
|---|---|
| **FORMING** | First closed bar that did not extend the candidate swing, while the price/MACD relation already shows a divergence |
| **CONFIRMED** | The swing is confirmed by the engine's swing rule and matched to a MACD pivot; the divergence relation still holds |
| **INVALIDATED** | A forming signal whose swing was extended, or whose final reading was not the same divergence |

**Repaint behaviour:**
- **Confirmed signals never repaint** and are never removed.
- **Forming signals** disappear when invalidated, which is their purpose.
- **Confirmation delay:**
  - The fast engine confirms a median of about 2 bars after the pivot.
  - The standard engine (swing = 4 × ATR14) confirms a median of about 12 bars after the pivot.
  - The exact delay of every signal is shown in its tooltip.

## 4. Settings
| Group | Input | Default | Notes |
|---|---|---|---|
| Engines | Use M5 / M1 | on / on | |
| | Use MACD 3,5,2 / 12,26,9 | on / on | |
| | Standard swing size (× ATR14) | 4.0 | smaller = earlier but fewer standard-engine signals |
| | M5 / M1 history bars | 6000 / 9000 | more bars = longer loading |
| Display | Regular / Hidden | on / on | |
| | Show forming | on | |
| | Pivot lines | on | |
| | Max labels per engine | 15 | |
| | Label font | 7 | |
| | Panel | on | |
| | Panel scale / font / dark | 1.0 / 8 / dark | |
| Alerts | Popup / Sound / Push | on / off / off | |
| | On FORMING / CONFIRMED / INVALIDATED | off / on / off | |
| | From M5 / From M1 | on / on | |

**Alert rules:**
- Each event alerts at most once per stage.
- History loaded at start-up never alerts.

## 5. Licence
- **Demo accounts:** the indicator runs as a free trial with every feature.
- **Real accounts:** they need a licence bound to your MT5 account number.
- **Installing your licence file `BQL_licence_<account>.txt`:**
  1. Open **File → Open Data Folder**.
  2. Go up one folder, then open **Common → Files**.
  3. Copy the file there and rename it to `BQL_licence.txt`.
  4. Reload the indicator.
- **Alternative:** paste the line from the file into the input **Licence key**.
- **Panel:** the health section shows the licence state, for example `licensed · account … · lifetime`.
- **Security:** licences are RSA-2048 signatures. The indicator contains only the public key, so licences cannot be generated from it. A licence for one account does not work on another.

## 6. Known limitations
- Only the M1 and M5 timeframes are supported in v1.0. Labels are drawn on M1 and M5 charts.
- The panel layout is designed for desktop chart sizes.
- Convergence events are calculated by the engine but are not shown in v1.0.
