BQL Divergence Intelligence v1.0.0
Copy the MQL5 folder into your MT5 data folder (File > Open Data Folder), restart MT5,
then drag the indicator onto an M1 or M5 chart. Enter your licence key in the inputs (demo accounts run as trial).
See USER_MANUAL.md.
